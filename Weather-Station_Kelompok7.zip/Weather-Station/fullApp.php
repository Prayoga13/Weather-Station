<?php

include 'layout/header.php';

?>

<div class="container" style="display: flex; justify-content: center; align-items: center; height: 100vh;">
    <div class="modern-box">
        <h2>Cooming Soon</h2>
        <p>Akan Disegerakan</p>
    </div>
</div>