<?php

include 'layout/header.php';

?>
<div class="container" style="display: flex; justify-content: center; align-items: center; height: 100vh;">
    <div class="modern-box">
        <div class="gambar-box" style="background-color:#d3d3d3; border-radius:12px; margin-bottom: 12px;">
            <img src="assets/weather/clear.svg" alt="">
            <img src="assets/weather/clouds.svg" alt="">
            <img src="assets/weather/atmosphere.svg" alt="">
            <img src="assets/weather/thunderstorm.svg" alt="">
        </div>
        <h2>WELCOME TO OUR WEBSITE</h2>
        <p>Selamat Datang Di Website Monitoring Prakiraan Cuaca Seluruh Kota Di Dunia</p>
    </div>
</div>